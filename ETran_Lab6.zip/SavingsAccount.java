package lab6;

public class SavingsAccount extends BankAccount //class that extends BankAccount
{
    private double rate = 0.025; //variables
    private int savingsNumber = 0;
    private String accountNumber;
    
    public SavingsAccount(String name, double initialBalance) 
    {
        super(name, initialBalance);
        this.accountNumber = super.getAccountNumber() + "-" + savingsNumber;
        savingsNumber++;
    }
    
    public SavingsAccount(SavingsAccount account, double initialBalance) 
    {
        super(account, initialBalance);
        savingsNumber = account.savingsNumber;
        accountNumber = super.getAccountNumber() + "-" + savingsNumber;
    }
    
    public void postInterest() //calculates months worth of interest
    {
        deposit(getBalance() * (rate/ 12));
    }
    
    public String getAccountNumber() 
    {
        return accountNumber;
    }  
}