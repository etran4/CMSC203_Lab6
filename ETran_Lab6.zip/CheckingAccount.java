package lab6;

public class CheckingAccount extends BankAccount //class that extends BankAccount
{
    public static final double FEE = 0.15; //fee
    
    public CheckingAccount(String name, double initialBalance)     
    {
        super(name, initialBalance);
        setAccountNumber(getAccountNumber() + "-10");
    }
    
    public boolean withdraw(double amount) 
    {
        amount += FEE;
        return super.withdraw(amount);
    }
}